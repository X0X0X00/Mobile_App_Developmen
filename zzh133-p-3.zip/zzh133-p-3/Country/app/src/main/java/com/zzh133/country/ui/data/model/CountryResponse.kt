package com.zzh133.country.ui.data.model

data class CountryResponse(
    val name: String,
    val capital: String,
    val region: String,
    val population: Int,
)